//test variables

var numberOfTestsToRun = 100;

//Test 3*3

//var pState = [[ 8, 5, 2 ],[ 4, 3, 6 ],[ 1, 7, 0 ]];
//p.loadState(pState);



/*
//Test BestFirstSolver
var b = new BestFirstSolver(p, solved);
let solution = b.solve(b.search());
p.getHtml();


for(let i = solution.length-1; i >= 0; i--) {
    //p.move(solution[i]);
    //p.getHtml();
}
*/

//Test BidirectionalBestFirstSolver


//console.log(solution);

class BidirectionalBestFirstSolverTest{

    test() {
        var bbfs;
        var p;
        var solved = new Puzzle(3);
        for(let i = 0; i < numberOfTestsToRun; i++) {
            p = new Puzzle(3);
            p.shuffle();
            bbfs = new BidirectionalBestFirstSolver(p, solved);
            bbfs.search();
            console.log(bbfs.logAnalytics());
        }
    }

}

new BidirectionalBestFirstSolverTest().test();